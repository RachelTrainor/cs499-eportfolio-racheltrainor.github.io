
package com.example.cs360projectracheltrainor;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Locale;

public class WeightActivity extends AppCompatActivity {

    private Database db;
    private LinearLayout entryContainer;
    private EditText inputDate, inputWeight, inputGoal, inputPhone;
    private Button addEntry, cancelEdit;
    private Spinner sortSpinner;

    private Long editingId = null;

    // ID of the currently logged-in user.
    private long userId = -1;

    // Keep weight limits in one place.
    private static final double MIN_WEIGHT = 1.0;
    private static final double MAX_WEIGHT = 1500.0;

    // Supported date formats.
    private static final DateTimeFormatter[] DATE_FORMATS = {
            DateTimeFormatter.ofPattern("M/d/uuuu", Locale.US)
                    .withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("M/d/uu", Locale.US)
                    .withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("M-d-uuuu", Locale.US)
                    .withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ofPattern("M-d-uu", Locale.US)
                    .withResolverStyle(ResolverStyle.STRICT),
            DateTimeFormatter.ISO_LOCAL_DATE
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_log);

        db = Database.getInstance(this);

        // Get the logged-in user's ID.
        userId = getIntent().getLongExtra("USER_ID", -1);

        if (userId == -1) {
            finish();
            return;
        }

        initializeViews();
        setupButtonListeners();
        setupSortSpinner();
        loadWeights();
    }

    /*
     * Connect the activity fields and buttons.
     */
    private void initializeViews() {

        inputDate = findViewById(R.id.input_date);
        inputWeight = findViewById(R.id.input_weight);
        inputGoal = findViewById(R.id.input_goal_weight);
        inputPhone = findViewById(R.id.input_phone);

        entryContainer = findViewById(R.id.entryContainer);

        addEntry = findViewById(R.id.button_add_entry);
        cancelEdit = findViewById(R.id.button_cancel_edit);
        sortSpinner = findViewById(R.id.sortSpinner);
    }

    /*
     * Set up sorting options.
     */
    private void setupSortSpinner() {

        String[] sortOptions = {
                "Oldest to Newest",
                "Newest to Oldest",
                "Lowest Weight",
                "Highest Weight"
        };

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                sortOptions
        );

        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        sortSpinner.setAdapter(adapter);

        sortSpinner.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {

                    @Override
                    public void onItemSelected(
                            AdapterView<?> parent,
                            View view,
                            int position,
                            long id
                    ) {
                        loadWeights();
                    }

                    @Override
                    public void onNothingSelected(
                            AdapterView<?> parent
                    ) {
                        // Keep the current sorting option.
                    }
                }
        );
    }

    /*
     * Set up button actions.
     */
    private void setupButtonListeners() {

        Button setGoal = findViewById(R.id.button_set_goal);
        Button home = findViewById(R.id.buttonHome);

        addEntry.setOnClickListener(
                v -> handleWeightEntry()
        );

        cancelEdit.setOnClickListener(
                v -> cancelEditMode()
        );

        setGoal.setOnClickListener(
                v -> handleGoalWeight()
        );

        home.setOnClickListener(v -> {

            Intent intent = new Intent(
                    WeightActivity.this,
                    HomeActivity.class
            );

            intent.putExtra("USER_ID", userId);

            startActivity(intent);
            finish();
        });
    }

    /*
     * Validate weight information before saving.
     */
    private void handleWeightEntry() {

        String date = inputDate.getText()
                .toString()
                .trim();

        String weightStr = inputWeight.getText()
                .toString()
                .trim();

        String phoneNumber = inputPhone.getText()
                .toString()
                .trim();

        if (date.isEmpty()) {

            inputDate.setError("Please enter a date");
            inputDate.requestFocus();
            return;
        }

        // Prevent unsupported or invalid dates.
        if (parseDate(date).equals(LocalDate.MAX)) {

            inputDate.setError(
                    "Enter a valid date (MM/DD/YYYY)"
            );

            inputDate.requestFocus();
            return;
        }

        if (weightStr.isEmpty()) {

            inputWeight.setError("Please enter your weight");
            inputWeight.requestFocus();
            return;
        }

        try {

            double weight = Double.parseDouble(weightStr);

            if (!isValidWeight(weight)) {

                inputWeight.setError(
                        "Weight must be between 1 and 1500"
                );

                inputWeight.requestFocus();
                return;
            }

            if (editingId != null) {

                updateWeightEntry(weight);

            } else {

                addWeightEntry(
                        date,
                        weight,
                        phoneNumber
                );
            }

        } catch (NumberFormatException e) {

            inputWeight.setError(
                    "Please enter a valid number"
            );

            inputWeight.requestFocus();
        }
    }

    /*
     * Check accepted weight range.
     */
    private boolean isValidWeight(double weight) {

        return !Double.isNaN(weight)
                && !Double.isInfinite(weight)
                && weight >= MIN_WEIGHT
                && weight <= MAX_WEIGHT;
    }

    /*
     * Add a weight record for the current user.
     */
    private void addWeightEntry(
            String date,
            double weight,
            String phoneNumber
    ) {

        long result = db.addWeightEntry(
                userId,
                date,
                weight
        );

        if (result > 0) {

            Toast.makeText(
                    this,
                    "Entry added",
                    Toast.LENGTH_SHORT
            ).show();

            double goal = db.getGoalWeight(userId);

            if (goal > 0 && weight <= goal) {

                handleGoalReached(phoneNumber);
            }

            clearWeightFields();
            loadWeights();

        } else {

            Toast.makeText(
                    this,
                    "Failed to add entry",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    /*
     * Update a record belonging to the current user.
     */
    private void updateWeightEntry(double weight) {

        boolean updated = db.updateWeight(
                userId,
                editingId,
                weight
        );

        if (updated) {

            Toast.makeText(
                    this,
                    "Entry updated",
                    Toast.LENGTH_SHORT
            ).show();

            exitEditMode();
            loadWeights();

        } else {

            Toast.makeText(
                    this,
                    "Update failed",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    /*
     * Clear weight entry fields.
     */
    private void clearWeightFields() {

        inputDate.setText("");
        inputWeight.setText("");
    }

    /*
     * Enter edit mode.
     */
    private void enterEditMode(
            long id,
            String date,
            double weight
    ) {

        editingId = id;

        inputDate.setText(date);
        inputWeight.setText(String.valueOf(weight));

        // The existing edit operation updates weight only.
        inputDate.setEnabled(false);

        addEntry.setText("Update Entry");
        cancelEdit.setVisibility(View.VISIBLE);

        inputWeight.requestFocus();
    }

    /*
     * Exit edit mode.
     */
    private void exitEditMode() {

        editingId = null;

        inputDate.setEnabled(true);

        addEntry.setText("Add");
        cancelEdit.setVisibility(View.GONE);

        clearWeightFields();
    }

    /*
     * Cancel editing.
     */
    private void cancelEditMode() {

        exitEditMode();

        Toast.makeText(
                this,
                "Edit canceled",
                Toast.LENGTH_SHORT
        ).show();
    }

    /*
     * Validate and save goal weight.
     */
    private void handleGoalWeight() {

        String goalStr = inputGoal.getText()
                .toString()
                .trim();

        if (goalStr.isEmpty()) {

            inputGoal.setError(
                    "Please enter a goal weight"
            );

            inputGoal.requestFocus();
            return;
        }

        try {

            double goalWeight = Double.parseDouble(goalStr);

            if (!isValidWeight(goalWeight)) {

                inputGoal.setError(
                        "Goal weight must be between 1 and 1500"
                );

                inputGoal.requestFocus();
                return;
            }

            boolean saved = db.setGoalWeight(
                    userId,
                    goalWeight
            );

            if (saved) {

                Toast.makeText(
                        this,
                        "Goal set: " + goalWeight,
                        Toast.LENGTH_SHORT
                ).show();

                inputGoal.setText("");

            } else {

                Toast.makeText(
                        this,
                        "Failed to save goal",
                        Toast.LENGTH_SHORT
                ).show();
            }

        } catch (NumberFormatException e) {

            inputGoal.setError(
                    "Please enter a valid number"
            );

            inputGoal.requestFocus();
        }
    }

    /*
     * Retrieve, sort, and display weight records.
     */
    private void loadWeights() {

        entryContainer.removeAllViews();

        ArrayList<WeightRecord> weightRecords =
                new ArrayList<>();

        Cursor cursor = db.getAllWeights(userId);

        try {

            if (cursor.moveToFirst()) {

                do {

                    long id = cursor.getLong(
                            cursor.getColumnIndexOrThrow(
                                    Database.W_ID
                            )
                    );

                    String date = cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    Database.W_DATE
                            )
                    );

                    double weight = cursor.getDouble(
                            cursor.getColumnIndexOrThrow(
                                    Database.W_WEIGHT
                            )
                    );

                    weightRecords.add(
                            new WeightRecord(
                                    id,
                                    date,
                                    weight
                            )
                    );

                } while (cursor.moveToNext());
            }

        } finally {

            cursor.close();
        }

        int sortOption = sortSpinner.getSelectedItemPosition();

        /*
         * Sort by actual calendar date instead of text.
         * Use record ID to keep equal dates consistent.
         */
        Comparator<WeightRecord> dateComparator =
                Comparator.comparing(
                        (WeightRecord record) ->
                                parseDate(record.getDate())
                ).thenComparingLong(
                        WeightRecord::getId
                );

        switch (sortOption) {

            case 1:

                // Newest to oldest.
                weightRecords.sort(
                        dateComparator.reversed()
                );

                break;

            case 2:

                // Lowest to highest weight.
                weightRecords.sort(
                        Comparator.comparingDouble(
                                WeightRecord::getWeight
                        ).thenComparing(dateComparator)
                );

                break;

            case 3:

                // Highest to lowest weight.
                weightRecords.sort(
                        Comparator.comparingDouble(
                                WeightRecord::getWeight
                        ).reversed().thenComparing(dateComparator)
                );

                break;

            default:

                // Oldest to newest.
                weightRecords.sort(dateComparator);

                break;
        }

        for (WeightRecord record : weightRecords) {

            createWeightRow(
                    record.getId(),
                    record.getDate(),
                    record.getWeight()
            );
        }
    }

    /*
     * Convert stored date strings into LocalDate.
     */
    private LocalDate parseDate(String date) {

        if (date == null || date.trim().isEmpty()) {
            return LocalDate.MAX;
        }

        String cleanedDate = date.trim();

        for (DateTimeFormatter formatter : DATE_FORMATS) {

            try {

                return LocalDate.parse(
                        cleanedDate,
                        formatter
                );

            } catch (DateTimeParseException ignored) {

                // Try the next supported format.
            }
        }

        // Unrecognized dates sort last in ascending order.
        return LocalDate.MAX;
    }

    /*
     * Create a row for one weight record.
     */
    private void createWeightRow(
            long id,
            String date,
            double weight
    ) {

        LinearLayout row = new LinearLayout(this);

        row.setOrientation(LinearLayout.HORIZONTAL);

        row.setPadding(8, 8, 8, 8);

        TextView dateView = createRowText(date);

        TextView weightView = createRowText(
                String.format(
                        Locale.US,
                        "%.1f",
                        weight
                )
        );

        Button editButton = createEditButton(
                id,
                date,
                weight
        );

        Button deleteButton = createDeleteButton(id);

        row.addView(dateView);
        row.addView(weightView);
        row.addView(editButton);
        row.addView(deleteButton);

        entryContainer.addView(row);
    }

    /*
     * Create text for each record.
     */
    private TextView createRowText(String text) {

        TextView textView = new TextView(this);

        textView.setText(text);

        textView.setLayoutParams(
                new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        1
                )
        );

        return textView;
    }

    /*
     * Create Edit button.
     */
    private Button createEditButton(
            long id,
            String date,
            double weight
    ) {

        Button editButton = new Button(this);

        editButton.setText("Edit");

        editButton.setOnClickListener(
                v -> enterEditMode(
                        id,
                        date,
                        weight
                )
        );

        return editButton;
    }

    /*
     * Create Delete button.
     */
    private Button createDeleteButton(long id) {

        Button deleteButton = new Button(this);

        deleteButton.setText("Delete");

        deleteButton.setBackgroundTintList(
                getResources().getColorStateList(
                        android.R.color.holo_red_dark,
                        null
                )
        );

        deleteButton.setTextColor(
                getResources().getColor(
                        android.R.color.white,
                        null
                )
        );

        deleteButton.setOnClickListener(
                v -> confirmDelete(id)
        );

        return deleteButton;
    }

    /*
     * Confirm before deleting a record.
     */
    private void confirmDelete(long id) {

        new AlertDialog.Builder(this)
                .setTitle("Delete Entry")
                .setMessage(
                        "Are you sure you want to delete " +
                                "this weight entry?"
                )
                .setPositiveButton(
                        "Delete",
                        (dialog, which) ->
                                deleteWeightEntry(id)
                )
                .setNegativeButton(
                        "Cancel",
                        (dialog, which) ->
                                dialog.dismiss()
                )
                .show();
    }

    /*
     * Delete only the current user's record.
     */
    private void deleteWeightEntry(long id) {

        boolean deleted = db.deleteWeight(
                userId,
                id
        );

        if (deleted) {

            if (editingId != null && editingId == id) {
                exitEditMode();
            }

            loadWeights();

            Toast.makeText(
                    this,
                    "Entry deleted",
                    Toast.LENGTH_SHORT
            ).show();

        } else {

            Toast.makeText(
                    this,
                    "Delete failed",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    /*
     * Handle goal notification.
     */
    private void handleGoalReached(String phoneNumber) {

        if (phoneNumber == null ||
                phoneNumber.isEmpty()) {

            Toast.makeText(
                    this,
                    "Goal reached! Add a phone number " +
                            "to receive an SMS.",
                    Toast.LENGTH_LONG
            ).show();

            return;
        }

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) != PackageManager.PERMISSION_GRANTED) {

            Toast.makeText(
                    this,
                    "Goal reached! SMS permission " +
                            "is not enabled.",
                    Toast.LENGTH_LONG
            ).show();

            return;
        }

        sendGoalSms(phoneNumber);
    }

    /*
     * Send goal notification SMS.
     */
    private void sendGoalSms(String phoneNumber) {

        try {

            SmsManager smsManager =
                    SmsManager.getDefault();

            smsManager.sendTextMessage(
                    phoneNumber,
                    null,
                    "Congratulations! You have " +
                            "reached your goal weight!",
                    null,
                    null
            );

            Toast.makeText(
                    this,
                    "Goal reached! SMS sent.",
                    Toast.LENGTH_SHORT
            ).show();

        } catch (Exception e) {

            Toast.makeText(
                    this,
                    "Goal reached, but the SMS " +
                            "could not be sent.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }
}
