package com.example.cs360projectracheltrainor;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText editUsername, editPassword;
    private Button btnLogin, btnRegister;
    private Database db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Connect UI elements to layout
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        btnLogin = findViewById(R.id.buttonLogin);
        btnRegister = findViewById(R.id.buttonRegister);

        db = Database.getInstance(this);

        btnLogin.setOnClickListener(v -> loginUser());
        btnRegister.setOnClickListener(v -> registerUser());
    }

    // User login
    private void loginUser() {

        String username =
                editUsername.getText().toString().trim();

        String password =
                editPassword.getText().toString();

        // Make sure input is not empty
        if (TextUtils.isEmpty(username) ||
                TextUtils.isEmpty(password)) {

            Toast.makeText(
                    this,
                    "Enter username and password",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        // Attempt login and retrieve the user's database ID
        long userId = db.loginUser(username, password);

        if (userId > 0) {

            Toast.makeText(
                    this,
                    "Login successful",
                    Toast.LENGTH_SHORT
            ).show();

            /*
             * Pass the logged-in user's ID to the Home screen.
             * This ID will be used to keep weight records
             * and goals separate for each account.
             */
            Intent intent =
                    new Intent(this, HomeActivity.class);

            intent.putExtra("USER_ID", userId);

            startActivity(intent);

        } else {

            Toast.makeText(
                    this,
                    "Invalid username or password",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    // User registration
    private void registerUser() {

        String username =
                editUsername.getText().toString().trim();

        String password =
                editPassword.getText().toString();

        // Make sure input is not empty
        if (TextUtils.isEmpty(username) ||
                TextUtils.isEmpty(password)) {

            Toast.makeText(
                    this,
                    "Enter username and password",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        // Attempt registration
        boolean registered =
                db.registerUser(username, password);

        if (registered) {

            Toast.makeText(
                    this,
                    "Account created! Please log in.",
                    Toast.LENGTH_SHORT
            ).show();

        } else {

            Toast.makeText(
                    this,
                    "Username already exists",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }
}