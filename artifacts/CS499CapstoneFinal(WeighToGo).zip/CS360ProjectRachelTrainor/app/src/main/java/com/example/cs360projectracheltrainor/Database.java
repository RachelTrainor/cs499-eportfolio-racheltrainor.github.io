package com.example.cs360projectracheltrainor;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

// Database class for managing user, weight, and goal data
public class Database extends SQLiteOpenHelper {

    private static final String DB_NAME = "weigh_to_go.db";

    /*
     * Database version increased because the database
     * structure now includes user relationships.
     */
    private static final int DB_VERSION = 4;

    // Users table
    public static final String T_USERS = "users";
    public static final String U_ID = "id";
    public static final String U_USERNAME = "username";
    public static final String U_PASSWORD = "password";

    // Weights table
    public static final String T_WEIGHTS = "weights";
    public static final String W_ID = "id";
    public static final String W_USER_ID = "user_id";
    public static final String W_DATE = "date";
    public static final String W_WEIGHT = "weight";

    // Goals table
    public static final String T_GOALS = "goals";
    public static final String G_ID = "id";
    public static final String G_USER_ID = "user_id";
    public static final String G_WEIGHT = "weight";

    private static volatile Database INSTANCE;

    // Singleton to keep only one database instance
    public static Database getInstance(Context ctx) {

        if (INSTANCE == null) {

            synchronized (Database.class) {

                if (INSTANCE == null) {

                    INSTANCE =
                            new Database(
                                    ctx.getApplicationContext()
                            );
                }
            }
        }

        return INSTANCE;
    }

    private Database(Context context) {

        super(
                context,
                DB_NAME,
                null,
                DB_VERSION
        );
    }

    /*
     * Enable foreign key support.
     */
    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);

        db.setForeignKeyConstraintsEnabled(true);
    }

    /*
     * Create the relational database tables.
     */
    @Override
    public void onCreate(SQLiteDatabase db) {

        // Create users table
        db.execSQL(
                "CREATE TABLE " + T_USERS + " (" +
                        U_ID +
                        " INTEGER PRIMARY KEY AUTOINCREMENT, " +

                        U_USERNAME +
                        " TEXT NOT NULL UNIQUE, " +

                        U_PASSWORD +
                        " TEXT NOT NULL)"
        );

        /*
         * Create weights table.
         * Each weight record belongs to one user.
         */
        db.execSQL(
                "CREATE TABLE " + T_WEIGHTS + " (" +
                        W_ID +
                        " INTEGER PRIMARY KEY AUTOINCREMENT, " +

                        W_USER_ID +
                        " INTEGER NOT NULL, " +

                        W_DATE +
                        " TEXT NOT NULL, " +

                        W_WEIGHT +
                        " REAL NOT NULL, " +

                        "FOREIGN KEY(" +
                        W_USER_ID +
                        ") REFERENCES " +
                        T_USERS +
                        "(" +
                        U_ID +
                        ") ON DELETE CASCADE)"
        );

        /*
         * Create goals table.
         * Each user can have one saved goal.
         */
        db.execSQL(
                "CREATE TABLE " + T_GOALS + " (" +
                        G_ID +
                        " INTEGER PRIMARY KEY AUTOINCREMENT, " +

                        G_USER_ID +
                        " INTEGER NOT NULL UNIQUE, " +

                        G_WEIGHT +
                        " REAL NOT NULL, " +

                        "FOREIGN KEY(" +
                        G_USER_ID +
                        ") REFERENCES " +
                        T_USERS +
                        "(" +
                        U_ID +
                        ") ON DELETE CASCADE)"
        );

        /*
         * Index the user ID in the weights table.
         * This improves lookups when retrieving
         * records for a specific user.
         */
        db.execSQL(
                "CREATE INDEX idx_weights_user " +
                        "ON " +
                        T_WEIGHTS +
                        "(" +
                        W_USER_ID +
                        ")"
        );
    }

    /*
     * Recreate the database when the structure changes.
     *
     * For this project, existing development/test data
     * can be recreated after the upgrade.
     */
    @Override
    public void onUpgrade(
            SQLiteDatabase db,
            int oldVersion,
            int newVersion
    ) {

        db.execSQL(
                "DROP TABLE IF EXISTS " +
                        T_GOALS
        );

        db.execSQL(
                "DROP TABLE IF EXISTS " +
                        T_WEIGHTS
        );

        db.execSQL(
                "DROP TABLE IF EXISTS " +
                        T_USERS
        );

        // Remove the old goal table if it exists
        db.execSQL(
                "DROP TABLE IF EXISTS goal_weight"
        );

        onCreate(db);
    }

    /*
     * Register a new user.
     */
    public boolean registerUser(
            String username,
            String password
    ) {

        try {

            ContentValues cv =
                    new ContentValues();

            cv.put(
                    U_USERNAME,
                    username.trim()
            );

            cv.put(
                    U_PASSWORD,
                    password
            );

            long id =
                    getWritableDatabase()
                            .insertOrThrow(
                                    T_USERS,
                                    null,
                                    cv
                            );

            return id > 0;

        } catch (Exception e) {

            Log.e(
                    "Database",
                    "registerUser failed",
                    e
            );

            return false;
        }
    }

    /*
     * Attempt login and return the user's
     * database ID when successful.
     */
    public long loginUser(
            String username,
            String password
    ) {

        Cursor cursor =
                getReadableDatabase().query(
                        T_USERS,
                        new String[]{
                                U_ID
                        },
                        U_USERNAME +
                                "=? AND " +
                                U_PASSWORD +
                                "=?",
                        new String[]{
                                username.trim(),
                                password
                        },
                        null,
                        null,
                        null
                );

        long id = -1;

        if (cursor.moveToFirst()) {

            id = cursor.getLong(0);
        }

        cursor.close();

        return id;
    }

    /*
     * Add a weight record belonging to
     * the logged-in user.
     */
    public long addWeightEntry(
            long userId,
            String date,
            double weight
    ) {

        ContentValues cv =
                new ContentValues();

        cv.put(
                W_USER_ID,
                userId
        );

        cv.put(
                W_DATE,
                date.trim()
        );

        cv.put(
                W_WEIGHT,
                weight
        );

        return getWritableDatabase().insert(
                T_WEIGHTS,
                null,
                cv
        );
    }

    /*
     * Retrieve only the weight records
     * belonging to the logged-in user.
     */
    public Cursor getAllWeights(long userId) {

        return getReadableDatabase().query(
                T_WEIGHTS,
                new String[]{
                        W_ID,
                        W_DATE,
                        W_WEIGHT
                },
                W_USER_ID + "=?",
                new String[]{
                        String.valueOf(userId)
                },
                null,
                null,
                W_ID + " DESC"
        );
    }

    /*
     * Update a weight record only if it
     * belongs to the logged-in user.
     */
    public boolean updateWeight(
            long userId,
            long weightId,
            double newWeight
    ) {

        ContentValues cv =
                new ContentValues();

        cv.put(
                W_WEIGHT,
                newWeight
        );

        int rows =
                getWritableDatabase().update(
                        T_WEIGHTS,
                        cv,
                        W_ID +
                                "=? AND " +
                                W_USER_ID +
                                "=?",
                        new String[]{
                                String.valueOf(weightId),
                                String.valueOf(userId)
                        }
                );

        return rows > 0;
    }

    /*
     * Delete a weight record only if it
     * belongs to the logged-in user.
     */
    public boolean deleteWeight(
            long userId,
            long weightId
    ) {

        int rows =
                getWritableDatabase().delete(
                        T_WEIGHTS,
                        W_ID +
                                "=? AND " +
                                W_USER_ID +
                                "=?",
                        new String[]{
                                String.valueOf(weightId),
                                String.valueOf(userId)
                        }
                );

        return rows > 0;
    }

    /*
     * Save or update the goal weight
     * belonging to a specific user.
     */
    public boolean setGoalWeight(
            long userId,
            double weight
    ) {

        SQLiteDatabase db =
                getWritableDatabase();

        ContentValues cv =
                new ContentValues();

        cv.put(
                G_USER_ID,
                userId
        );

        cv.put(
                G_WEIGHT,
                weight
        );

        /*
         * Check whether this user already
         * has a goal stored.
         */
        Cursor cursor =
                db.query(
                        T_GOALS,
                        new String[]{
                                G_ID
                        },
                        G_USER_ID + "=?",
                        new String[]{
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        null
                );

        boolean goalExists =
                cursor.moveToFirst();

        cursor.close();

        if (goalExists) {

            int rows =
                    db.update(
                            T_GOALS,
                            cv,
                            G_USER_ID + "=?",
                            new String[]{
                                    String.valueOf(userId)
                            }
                    );

            return rows > 0;

        } else {

            long result =
                    db.insert(
                            T_GOALS,
                            null,
                            cv
                    );

            return result > 0;
        }
    }

    /*
     * Retrieve the goal belonging to
     * the logged-in user.
     */
    public double getGoalWeight(long userId) {

        Cursor cursor =
                getReadableDatabase().query(
                        T_GOALS,
                        new String[]{
                                G_WEIGHT
                        },
                        G_USER_ID + "=?",
                        new String[]{
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        null,
                        "1"
                );

        double goal = -1;

        if (cursor.moveToFirst()) {

            goal = cursor.getDouble(0);
        }

        cursor.close();

        return goal;
    }

    /*
     * Retrieve the most recently added
     * weight belonging to the logged-in user.
     */
    public double getLatestWeight(long userId) {

        Cursor cursor =
                getReadableDatabase().query(
                        T_WEIGHTS,
                        new String[]{
                                W_WEIGHT
                        },
                        W_USER_ID + "=?",
                        new String[]{
                                String.valueOf(userId)
                        },
                        null,
                        null,
                        W_ID + " DESC",
                        "1"
                );

        double weight = -1;

        if (cursor.moveToFirst()) {

            weight =
                    cursor.getDouble(0);
        }

        cursor.close();

        return weight;
    }

    /*
     * Return the total number of weight records
     * belonging to the logged-in user.
     */
    public int getWeightEntryCount(long userId) {

        Cursor cursor =
                getReadableDatabase().rawQuery(
                        "SELECT COUNT(*) FROM " +
                                T_WEIGHTS +
                                " WHERE " +
                                W_USER_ID +
                                "=?",
                        new String[]{
                                String.valueOf(userId)
                        }
                );

        int count = 0;

        if (cursor.moveToFirst()) {

            count = cursor.getInt(0);
        }

        cursor.close();

        return count;
    }

    /*
     * Return the lowest recorded weight
     * belonging to the logged-in user.
     */
    public double getLowestWeight(long userId) {

        Cursor cursor =
                getReadableDatabase().rawQuery(
                        "SELECT MIN(" +
                                W_WEIGHT +
                                ") FROM " +
                                T_WEIGHTS +
                                " WHERE " +
                                W_USER_ID +
                                "=?",
                        new String[]{
                                String.valueOf(userId)
                        }
                );

        double lowest = -1;

        if (cursor.moveToFirst() &&
                !cursor.isNull(0)) {

            lowest = cursor.getDouble(0);
        }

        cursor.close();

        return lowest;
    }

    /*
     * Return the highest recorded weight
     * belonging to the logged-in user.
     */
    public double getHighestWeight(long userId) {

        Cursor cursor =
                getReadableDatabase().rawQuery(
                        "SELECT MAX(" +
                                W_WEIGHT +
                                ") FROM " +
                                T_WEIGHTS +
                                " WHERE " +
                                W_USER_ID +
                                "=?",
                        new String[]{
                                String.valueOf(userId)
                        }
                );

        double highest = -1;

        if (cursor.moveToFirst() &&
                !cursor.isNull(0)) {

            highest = cursor.getDouble(0);
        }

        cursor.close();

        return highest;
    }

    /*
     * Return the average recorded weight
     * belonging to the logged-in user.
     */
    public double getAverageWeight(long userId) {

        Cursor cursor =
                getReadableDatabase().rawQuery(
                        "SELECT AVG(" +
                                W_WEIGHT +
                                ") FROM " +
                                T_WEIGHTS +
                                " WHERE " +
                                W_USER_ID +
                                "=?",
                        new String[]{
                                String.valueOf(userId)
                        }
                );

        double average = -1;

        if (cursor.moveToFirst() &&
                !cursor.isNull(0)) {

            average = cursor.getDouble(0);
        }

        cursor.close();

        return average;
    }
}