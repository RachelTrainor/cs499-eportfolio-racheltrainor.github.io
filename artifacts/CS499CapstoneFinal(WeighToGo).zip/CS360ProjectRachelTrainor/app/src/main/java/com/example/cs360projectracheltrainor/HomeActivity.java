package com.example.cs360projectracheltrainor;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    // Display current and goal weight
    private TextView currentWeightDisplay;
    private TextView goalWeightDisplay;
    private Database db;

    // Stores the ID of the currently logged-in user
    private long userId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Get instance of database
        db = Database.getInstance(this);

        // Get the logged-in user's ID
        userId = getIntent().getLongExtra("USER_ID", -1);

        /*
         * If no valid user ID was received,
         * return to the login screen.
         */
        if (userId == -1) {

            Intent intent = new Intent(
                    HomeActivity.this,
                    LoginActivity.class
            );

            intent.setFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK |
                            Intent.FLAG_ACTIVITY_CLEAR_TASK
            );

            startActivity(intent);
            finish();
            return;
        }

        // Connect UI elements to layout
        currentWeightDisplay =
                findViewById(R.id.currentWeightDisplay);

        goalWeightDisplay =
                findViewById(R.id.goalWeightDisplay);

        // Button for SMS permissions screen
        Button buttonPermissions =
                findViewById(R.id.buttonPermissions);

        // Button for weight log screen
        Button buttonWeightLog =
                findViewById(R.id.buttonWeightLog);

        // Button for progress screen
        Button buttonProgress =
                findViewById(R.id.buttonProgress);

        // Logout button
        Button logout =
                findViewById(R.id.buttonLogout);

        /*
         * Transition animation for
         * SMS permissions screen.
         */
        buttonPermissions.setOnClickListener(v -> {

            Intent intent = new Intent(
                    HomeActivity.this,
                    Activity_sms.class
            );

            ActivityOptions options =
                    ActivityOptions.makeCustomAnimation(
                            HomeActivity.this,
                            android.R.anim.fade_in,
                            android.R.anim.fade_out
                    );

            startActivity(
                    intent,
                    options.toBundle()
            );
        });

        /*
         * Open the weight log and pass the
         * logged-in user's database ID.
         */
        buttonWeightLog.setOnClickListener(v -> {

            Intent intent = new Intent(
                    HomeActivity.this,
                    WeightActivity.class
            );

            intent.putExtra(
                    "USER_ID",
                    userId
            );

            ActivityOptions options =
                    ActivityOptions.makeCustomAnimation(
                            HomeActivity.this,
                            android.R.anim.fade_in,
                            android.R.anim.fade_out
                    );

            startActivity(
                    intent,
                    options.toBundle()
            );
        });

        /*
         * Open the progress screen and pass
         * the logged-in user's database ID.
         */
        buttonProgress.setOnClickListener(v -> {

            Intent intent = new Intent(
                    HomeActivity.this,
                    ProgressActivity.class
            );

            intent.putExtra(
                    "USER_ID",
                    userId
            );

            ActivityOptions options =
                    ActivityOptions.makeCustomAnimation(
                            HomeActivity.this,
                            android.R.anim.fade_in,
                            android.R.anim.fade_out
                    );

            startActivity(
                    intent,
                    options.toBundle()
            );
        });

        /*
         * Logout and clear the activity stack
         * so the previous user's session
         * cannot be reopened with the Back button.
         */
        logout.setOnClickListener(v -> {

            Intent intent = new Intent(
                    HomeActivity.this,
                    LoginActivity.class
            );

            intent.setFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK |
                            Intent.FLAG_ACTIVITY_CLEAR_TASK
            );

            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        /*
         * Retrieve only the logged-in user's
         * goal and most recent weight.
         */
        double goal =
                db.getGoalWeight(userId);

        double current =
                db.getLatestWeight(userId);

        // Update UI with current weight
        currentWeightDisplay.setText(
                "Current Weight: " +
                        (current > 0
                                ? current
                                : "N/A")
        );

        // Update UI with goal weight
        goalWeightDisplay.setText(
                "Goal Weight: " +
                        (goal > 0
                                ? goal
                                : "Not Set")
        );
    }
}